# Projetos do curso Aula Devops Fundamentals

codigoTerraform: recurso Terraform para a criação no Azure

website: site html para ser utilizado como teste no Git
